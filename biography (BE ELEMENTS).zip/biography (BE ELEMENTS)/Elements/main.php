 <main>
       
       <img alt src="assets/images/my_pic.png" class = "image">
       
       <div id = "my_info">Name : Christian Ehd S. Garces<br><br>Birth Date : March 14, 2001<br><br>Address : Canduman, Mandaue City <br><br>
       Hobby : Playing Basketball and Chess <br><br> Religion : Roman Catholic <br><br> Check Me Out On :
    
      </div>

    
    
       <a href= "https://www.facebook.com/garces314">Facebook</a>

     </main>
</html>