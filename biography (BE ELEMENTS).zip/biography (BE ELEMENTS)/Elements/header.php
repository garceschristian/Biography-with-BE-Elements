<!DOCTYPE html>

<html> 
    <head>
     <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title> Biography </title>
      <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    </head>
 
      <body>
          

          <div id = "background"></div>
        <header>
            
              
       
             <div id="title">My Biography</div>
          
             
        </header>
